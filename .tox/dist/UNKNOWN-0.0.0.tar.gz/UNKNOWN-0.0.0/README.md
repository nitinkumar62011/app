create
```bash
conda create -n env
```
```bash
conda activate env
```
